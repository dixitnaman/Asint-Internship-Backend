package com.ratingmanagement.demo;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class RatingManagementApplicationTests {

	@Test
	void contextLoads() {
	}

}
